package com.technicalsand.sse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServerSentEventsSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServerSentEventsSpringApplication.class, args);
	}

}
